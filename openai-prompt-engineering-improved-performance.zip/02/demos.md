# OpenAI Prompt Engineering for Improved Performance Study Resources, by Tim Warner

## Contact info

- [Email](mailto:tim-warner@pluralsight.com)
- [Website](https://techtrainertim.com)
- [LinkedIn](https://timw.info/li)
- [Courses](https://timw.info/ps)

## ChatGPT Enterprise

- [Marketing page](https://openai.com/enterprise)
- [Announcement post](https://openai.com/blog/introducing-chatgpt-enterprise)
- [FAQ](https://help.openai.com/en/collections/5688074-chatgpt-enterprise)

## ChatGPT Mobile Apps

- [iOS](https://apps.apple.com/us/app/chatgpt/id6448311069)
- [Android](https://play.google.com/store/apps/details?id=com.openai.chatgpt&hl=en_US&gl=US)

## Prompt Engineering

- [Best practices](https://help.openai.com/en/articles/6654000-best-practices-for-prompt-engineering-with-openai-api)
- [Prompt engineering for developers](https://www.deeplearning.ai/short-courses/chatgpt-prompt-engineering-for-developers/)
- [Beginner's guide](https://www.datacamp.com/tutorial/a-beginners-guide-to-chatgpt-prompt-engineering)
- [Few-shot learning white paper](https://arxiv.org/pdf/2005.14165.pdf)

## Cost Management

- [Tiktoken Python library](https://github.com/openai/tiktoken)
- [Let's explore the Tiktoken library](https://medium.com/@basics.machinelearning/tokenization-in-openai-api-lets-explore-tiktoken-library-d02d3ce94b0a)

## Benchmarking GPT

- [The right benchmark for GPT](https://hackaday.com/2023/07/29/the-right-benchmark-for-gpt/)
- [Auto GPT benchmarks](https://github.com/Significant-Gravitas/Auto-GPT-Benchmarks)
- [GPT-Fathom](https://paperswithcode.com/paper/gpt-fathom-benchmarking-large-language-models)
- Promehttps://gpt3demo.com/apps/microsoft-prometheustheus
- [Grafana](https://grafana.com/blog/2023/07/25/lessons-learned-from-integrating-openai-into-a-grafana-data-source/)
- [ELK Stack](https://www.elastic.co/search-labs/chatgpt-elasticsearch-openai-meets-private-data)
- [AWS CloudWatch](https://aws.amazon.com/blogs/storage/accelerating-gpt-large-language-model-training-with-aws-services/)
- [Google Cloud Monitoring and Logging](https://cloud.google.com/products/operations)
- [Microsoft Azure Monitor Logs](https://learn.microsoft.com/en-us/azure/ai-services/openai/how-to/monitoring)
